/**
 * CPE/CSC 159 - Operating System Pragmatics
 * California State University, Sacramento
 * Fall 2020
 *
 * String Utilities
 */

#include "string.h"
#include "spede.h"
//#include <stdbool.h>
//#include <stdio.h>
//#define NULL 0
typedef enum {false, true} bool;
/**
 * Sets the first n bytes pointed to by str to the value specified by c
WE THINK IT WORK :)
 *
 * @param   dest - pointer the block of memory to set
 * @param   c    - value to set; passed as an integer but converted to unsigned
 * char when set
 * @param   n    - number of bytes to set
 * @return  pointer to the memory region being set; NULL on error
 */
void *sp_memset(void *dest, int c, size_t n) {
	int i = 0;
	unsigned char *mem = dest;
	//unsigned char val = c;
	//printf("%s \n",val);	
	for (i; i < n; i++ ){ 
		mem[i] = (unsigned char)c;
	}
    return dest;
}

/**
 * Copies n bytes from the block of memory pointed to by src to dest
 *
 * @param   dest - pointer to the destination block of memory
 * @param   src  - pointer to the source block of memory
 * @param   n    - number of bytes to read/set
 * @return  pointer to the destination memory region; NULL on error
 */
void *sp_memcpy(void *dest, const void *src, size_t n) {

    unsigned int i = 0;
	unsigned char *mem = dest;
	//void *nulptr = NUL;
	//unsigned char *mem2 = src;

	for(i; i < n; i++) {
		if(&src[i] != NULL )
			mem[i] = &src[i];
	}
	if (mem != NULL) {
		return mem;
	}else
		return NULL;

}

/**
 * Compares the first n bytes of memory pointed to by str1 and str2
 *
 * @param  s1  - pointer to a block of memory
 * @param  s2  - pointer to a block of memory.
 * @param  n   - number of bytes to compare
 * @return  0 if every byte in s1 is equal to s2 or if n is 0
 *         <0 if the first non-matching byte of s1 is less than that of s2
 *         >0 if the first non-matching byte of s1 is greater than that of s2
 *         For a non-zero value the value will indicate the difference
 */
int sp_memcmp(const void *str1, const void *str2, size_t n) {
	unsigned int i = 0;
	//const void result;
	//unsigned char *mem = str1;
	//unsigned char *mem2 = str2;

	// 0 all bytes same
	// -1 (first byte that != ) < s2
	// 1 (first byte that != ) > s2
	
	for(i; i < n; i++) {
		if(&str1[i] != &str2[i]) {
			return &str1[i] - &str2[i]; 
		}
	}
	return 0;
}

/**
 * Computes the length of the string str up to, but not including the null
 * terminating character
 *
 * @param  str - pointer to the string
 * @return length of the string
 */
size_t sp_strlen(const char *str) {
	
	unsigned int len = 0;
	unsigned int i = 0;
	
	while (str[i]) {
		i++;
		len++;
	}
	
	
    return len;
}

/**
 * Copies the string pointed to by src to the destination dest
 *
 * @param  dest - pointer to the destination string
 * @param  src  - pointer to the source string
 * @return pointer to the destination string
 */
char *sp_strcpy(char *dest, const char *src) {
	
	unsigned int i = 0;
	while (src[i]) {
		dest[i] = src[i];
		i++;
	}
	
    return dest;
}

/**
 * Copies up to n characters from the source string src to the destination
 * string dest. If the length of src is less than that of n, the remainder
 * of dest up to n will be filled with NULL characters.
 *
 * @param  dest - pointer to the destination string
 * @param  src  - pointer to the source string
 * @param  n    - maximum number of characters to be copied
 * @return pointer to the destination string
 */
char *sp_strncpy(char *dest, const char *src, size_t n) {
	//unsigned int len = sp_strlen(src);
/*
	bool temp;
	if(len < n) {
		temp = false;
	}
*/
    	int i = 0;
	while (src[i]) {
		dest[i] = src[i];
		i++;
	}
	
	if(i < n) {
		for(i; i < n; i++) {
			dest[i] = NULL;
		}
	}
	
    return dest;
} // ?

/**
 * Compares the string pointed to by str1 to the string pointed to by str2
 *
 * @param  str1 - pointer to the string str1
 * @param  str2 - pointer to the string str2
 * @return  0 if every character in str1 is equal to str2
 *         <0 if the first non-matching character of str1 is less than that of
 * str2 >0 if the first non-matching character of str1 is greater than that of
 * str2 For a non-zero value the value will indicate the difference
 */
int sp_strcmp(const char *str1, const char *str2) {
    unsigned int len = sp_strlen(str1);
	unsigned int len2 = sp_strlen(str2);
	unsigned int i = 0;
	
	if(len != len2) {
		return (len-len2);
	} else {
		for(i; i <= len; i++) {
			if(str1[i] != str2[i]) {
				return (str1[i] - str2[i]); 
			}
		}
	}
    return 0;
	
	// comapre : str1 = test | str2 = tester
	// len = 4
	// for 0 --> 4 
}

/**
 * Compares the string pointed to by str1 to the string pointed to by str2 up to
 * the first n characters
 *
 * @param  str1 - pointer to the string str1
 * @param  str2 - pointer to the string str2
 * @param  n    - maximum number of characters to be compared
 * @return  0 if every character in str1 is equal to str2 or if n is 0
 *         <0 if the first non-matching character of str1 is less than that of
 * str2 >0 if the first non-matching character of str1 is greater than that of
 * str2 For a non-zero value the value will indicate the difference
 */
int sp_strncmp(const char *str1, const char *str2, size_t n) {
	unsigned int i = 0;
	
    for(i; i < n; i++) {
		if(str1[i] != str2[i]) {
			return (str1[i] - str2[i]); 
		}
	}
    return 0;
}
