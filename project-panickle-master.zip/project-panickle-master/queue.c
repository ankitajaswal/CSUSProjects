/**
 * CPE/CSC 159 - Operating System Pragmatics
 * California State University, Sacramento
 * Fall 2020
 *
 * Queue Utilities
 */

#include "queue.h"
#define TRASH


/**
 * Adds an item to the end of a queue
 * @param  queue - pointer to the queue
 * @param  item  - the item to add
 * @return -1 on error; 0 on success
 */
int enqueue(queue_t *queue, int item) {
    // Return an error if the queue is full
	if(queue->size == QUEUE_SIZE) {
		printf("Error : Queue is full \n");
		return -1;
	}
	else {

		queue->items[queue->tail] = item;
		queue->tail++;
	} 
    // Add the item to the tail of the queue
    // Move the tail forward
    // If we are at the end of the array, move the tail to the beginning
	if(queue->tail == QUEUE_SIZE) {
		queue->tail = 0;
	}
    // Increment size (since we just added an item to the queue)
	queue->size++;
   // printf("%d \n",item);
    return 0;
}

/**
 * Pulls an item from the specified queue
 * @param  queue - pointer to the queue
 * @return -1 on error; 0 on success

HOW DO ASSGIN ITEM TO AN ACTUAL VALUE , THE ONE PASSED IN ** or CHANGE BACK TO THE OREGANO VERISON
 */
int dequeue(queue_t *queue, int *item) {
    // Return an error if queue is empty
	//printf("%d head \n", queue->head); // testing
	//printf("%d\n queue size",queue->size);
	if(queue->size == 0) {
		//printf("Error : Queue is empty \n");
		return -1;
	}
    // Get the item from the head of the queue
	//int temp = queue->items[&item+1]; // item = location of process dequeued 
    // Move the head forward
	*item = (queue->items[queue->head]); 
	queue->head++;
    // If we are at the end of the array, move the head to the beginning
	if(queue->head == QUEUE_SIZE) {
		queue->head = 0;
	}
    // Decrement size (since we just removed an item from the queue)
	queue->size--;

	//printf("%d head \n", queue->head); // testing
    return 0;
}
