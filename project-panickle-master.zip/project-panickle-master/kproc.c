/**
 * CPE/CSC 159 - Operating System Pragmatics
 * California State University, Sacramento
 * Fall 2020
 *
 * Kernel Process Handling
 */
#include "spede.h"
#include "kernel.h"
#include "kproc.h"
#include "queue.h"
#include "string.h"
//#define NULL
//#include <stdio.h>
//#include <stdbool.h> // get rid of em 

/**
 * Process scheduler
*/
void kproc_schedule() {
	//int tmp;
    // if we already have an active process that is running, we should simply return
	if (run_pid >= 0) {
		return;
	}
		// if it is a valid process
		// if run_q.size == 0 && idle_q size != 0 
		// dequeue(idle_q,run_pid); 
		//
			if(dequeue(&run_q,&run_pid) == 0 ) {  // proc is not being put back into idle after it leaves schedule
				pcb[run_pid].state = RUNNING;
			}else if(dequeue(&idle_q,&run_pid) == 0 ) { 
				pcb[run_pid].state = RUNNING;
			} else
				panic("No process to schd\n");
		
		if(run_pid < 0 || run_pid > PROC_MAX ) {
			panic("Not a valid running process\n"); // check 
		}
    //   Set the active running PID

    //   Set the process state to RUNNING
    //
    // if a process cannot be dequeued, trigger a panic
    //
    // if we don't have a valid running process, trigger a panic

    debug_printf("Scheduled process %s (pid=%d)\n", pcb[run_pid].name, run_pid);
}

/**
 * Start a new process
 * @param proc_name The process title
 * @param proc_ptr  function pointer for the process
 * @param queue     the run queue in which this process belongs
 */
void kproc_exec(char *proc_name, void *proc_ptr, queue_t *queue) {
    	int pid = 0;

    // Ensure that valid parameters have been specified
	//char *tmp;
	
  	if(proc_name != NULL && proc_ptr != NULL && queue != NULL) {
			if(dequeue(&available_q,&pid)  == 0 )	{	
				//sp_strncpy(pcb[pid].name, proc_name,PROC_NAME_LEN);
				sp_strcpy(pcb[pid].name, proc_name);
				pcb[pid].state = READY;
				pcb[pid].time = 0;
				pcb[pid].total_time = 0;
				pcb[pid].wake_time = 0;
			} else
				panic_warn("Cannot dequeue \n");
	} else {
		panic("Null values passed in \n");
	}

    // Dequeue the process from the available queue

    // If a process cannot be dequeued, trigger a warning

    // Initialize the PCB
	//sp_memset(pcb[pid],0,sizeof(pcb[pid]));	
    //   Set the process state to READY
    //   Initialize other process control block variables to default values
    //   Copy the process name to the PCB
    //   Ensure the stack for the process is initialized

	//tmp = sp_memset(&stack,0,sizeof(stack));
	//sp_memcpy(&stack,tmp,sizeof(stack));
	sp_memset(stack[pid],0,sizeof(stack[pid]));

    // Allocate the trapframe data
    pcb[pid].trapframe_p = (trapframe_t *)&stack[pid][PROC_STACK_SIZE - sizeof(trapframe_t)];

    // Set the instruction pointer in the trapframe
    pcb[pid].trapframe_p->eip = (unsigned int)proc_ptr;

    // Set INTR flag
    pcb[pid].trapframe_p->eflags = EF_DEFAULT_VALUE | EF_INTR;

    // Set each segment in the trapframe
    pcb[pid].trapframe_p->cs = get_cs();
    pcb[pid].trapframe_p->ds = get_ds();
    pcb[pid].trapframe_p->es = get_es();
    pcb[pid].trapframe_p->fs = get_fs();
    pcb[pid].trapframe_p->gs = get_gs();

    // Set the process run queue (supplied as argument)
    // Move the proces into the associated run queue
	pcb[pid].queue = queue;
	enqueue(pcb[pid].queue,pid); 


    debug_printf("Started process %s (pid=%d)\n", pcb[pid].name, pid);
}

/**
 * Exit the currently running process
 */
void kproc_exit() {
    // PID 0 should be our kernel idle task.
    // It should never exit.


   	if( run_pid == 0) { // testing orginally 0 // how do determine idle??????????
		return;
	} 

	// Panic if we have an invalid PID
	if (run_pid < 0 || run_pid > PID_MAX) {
		panic("Invalid PID! \n");
	}

	debug_printf("Exiting process %s (pid=%d)\n", pcb[run_pid].name, run_pid);

	// Change the state of the running process to AVAILABLE
	// Queue it back to the available queue
	// clear the running pid
	pcb[run_pid].state = AVAILABLE;
	enqueue(&available_q,run_pid); // still prob wrong
	run_pid = -1;

	// Trigger the scheduler to load the next process
	kproc_schedule();
		//kproc_load(pcb[run_pid].trapframe_p);
}


/**
 * Kernel idle task
 */
void ktask_idle() {
   int i;

    // Indicate that the Idle Task has started
    cons_printf("idle_task started\n");

    // Process run loop
    while (1) {
		
		asm("hlt");
		/*
		        cons_printf("idle_task running\n");

        // busy loop/delay
        for (i = 0; i < IO_DELAY_LOOP; i++) {
            IO_DELAY();
        }
		*/
    }
}

