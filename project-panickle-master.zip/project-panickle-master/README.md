# project-panickle
project-panickle created by GitHub Classroom

V1.0
-----------------------------------------------------------------------------------------------------------------------------------------------------

When the program runs displays idle task(pid=0)

"n" command scheduels new "user proc" but PID is unchanged 

"x" cmd breaks the host/target unsure why

queue.c -> deqeue possibly not working 

kproc.c / kisr.c : We think the problem lies in these two files specially the kproc_scheduel() and kisr_timer() being looped over/over but the queues
are not keeping up properly.

------------------------------------------------------------------------------------------------------------------------------------------------------


V2.0
------------------------------------------------------------------------------------------------------------------------------------------------------

Currently runs displays all info except current time right, its off by 1second constantly, tried changing up the order of operations within kisr_timer but doesn't seem to affect it thinking its how the math is done at some point during the syscalls unsure.
"x" command seems to be not working depedent on when you click it unsure if its have to do with timing 

------------------------------------------------------------------------------------------------------------------------------------------------------


V3.0
------------------------------------------------------------------------------------------------------------------------------------------------------

No seg faults, Runs inital 3 proccess then infinitely schedules printer process no idea why, thinking it has something to do with asm code passing in sem_t's value or us refrencing the trapframe in the ksyscalls or a pointer thing its always a pointer thing. 
das it.

------------------------------------------------------------------------------------------------------------------------------------------------------

