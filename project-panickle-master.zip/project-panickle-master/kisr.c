/**
 * CPE/CSC 159 - Operating System Pragmatics
 * California State University, Sacramento
 * Fall 2020
 *
 * Kernel Interrupt Service Routines
 */

#include "spede.h"
#include "kernel.h"
#include "kisr.h"
#include "kproc.h"
#include "queue.h"
#include "string.h"
//#include <stdio.h>

/**
 * Kernel Interrupt Service Routine: Timer (IRQ 0)

 */

void kisr_timer() {
    // Increment the system time
	int tmp_pid;
	int i=0;
		
	for(i; i < sleep_q.size; i++) {
		if(dequeue(&sleep_q,&tmp_pid) == 0) {
			if( (system_time == pcb[tmp_pid].wake_time) ) { // if wake time is 0 it should wake up 		 
				// put it into runq
				enqueue(&run_q,tmp_pid);
				pcb[tmp_pid].state == READY;
			}else {
				enqueue(&sleep_q,tmp_pid);
			}				
		}else 
			panic("Cannot dequeue from sleep queue\n");	
	} 
	system_time++;   

    // If the running PID is invalid, just return
    // Since this is a hardware driven interrupt, make sure
    // to dismiss the IRQ
	if(run_pid  == -1 ) {  
		outportb(0x20, 0x60); // dismissing IRQ before returning
		return;
	} 
	
	pcb[run_pid].time++;  
	
	if (pcb[run_pid].time >= PROC_TICKS_MAX) {
		// Increment the running process' current run time
			//   set the total run time
			//   reset the current running time
			pcb[run_pid].total_time += pcb[run_pid].time ; 
			pcb[run_pid].time = 0;
			//   set the state to ready
			pcb[run_pid].state = READY;  
			//   queue the process back into the running queue
			enqueue(pcb[run_pid].queue,run_pid);
			//enqueue(&run_q,run_pid);
			//   clear the running pid
			run_pid = -1;
	}

	    // Once the running process has exceeded the maximum
	    // number of ticks, it needs to be unscheduled:

	    // Dismiss IRQ 0 (Timer)
    outportb(0x20, 0x60);
} // end timer
/*
    Detects the system call that was performed (via the eax register)
    Calls the appropriate system kernel function
       -May be existing kernel function (such as kproc_exit())
       -May be a new kernel function (such as ksyscall_get_proc_pid())
*/
void kisr_syscall() {
	int syscall;
	
	if (run_pid < 0 || run_pid > PID_MAX) {
        panic("Invalid PID");
    }
	
	syscall = pcb[run_pid].trapframe_p->eax;
	
	switch(syscall)  { // get whatever is in EAX
	
		case SYSCALL_PROC_EXIT:
			ksyscall_exit();
			break;
		case SYSCALL_GET_SYS_TIME:
			ksyscall_get_sys_time();
			break;
		case SYSCALL_GET_PROC_PID:
			ksyscall_get_proc_pid();
			break;
		case SYSCALL_GET_PROC_NAME:
			ksyscall_get_proc_name();
			break;
		case SYSCALL_SLEEP:
			ksyscall_sleep();
			break;
		case SYSCALL_SEM_INIT:
			ksyscall_sem_init();
			break;
		case SYSCALL_SEM_WAIT:
			ksyscall_sem_wait();
			break;
		case SYSCALL_SEM_POST:
			ksyscall_sem_post();
			break;
		case SYSCALL_MSG_SEND:
			ksyscall_msg_send();
			break;
		case SYSCALL_MSG_RECV:
			ksyscall_msg_recv();
			break;

		default:
			panic("Invalid system call!!! \n");
			break;
	} // end switch
	
} // end syscall
