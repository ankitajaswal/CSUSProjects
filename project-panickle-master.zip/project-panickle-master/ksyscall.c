/**
 * CPE/CSC 159 - Operating System Pragmatics
 * California State University, Sacramento
 * Fall 2020
 *
 * System call APIs - Kernel Side
 */
#include "spede.h"
#include "kernel.h"
#include "kproc.h"
#include "string.h"
#include "queue.h"
#include "ksyscall.h"
#include "ipc.h"


/**
 * System call kernel handler: get_sys_time
 * Returns the current system time (in seconds)
 */
void ksyscall_get_sys_time() {
    // Don't do anything if the running PID is invalid
    // Copy the system time from the kernel to the
    // eax register via the running process' trapframe
	if (run_pid < 0 || run_pid > PID_MAX) {
        panic("Invalid PID");
    }
	pcb[run_pid].trapframe_p->ebx = system_time / 100;
}

/**
 * System call kernel handler: get_proc_id
 * Returns the currently running process ID
 */
void ksyscall_get_proc_pid() {
    // Don't do anything if the running PID is invalid
    if (run_pid < 0 || run_pid > PID_MAX) {
        panic("Invalid PID");
    }

    // Copy the running pid from the kernel to the
    // eax register via the running process' trapframe
    pcb[run_pid].trapframe_p->ebx = run_pid;
}

/**
 * System call kernel handler: get_proc_name
 * Returns the currently running process name
 */
void ksyscall_get_proc_name() {  
    // Don't do anything if the running PID is invalid
    // Set the destination pointer to the address passed in via EBX
    // Copy the string name from the PCB to the destination
	
	if (run_pid < 0 || run_pid > PID_MAX) {
        panic("Invalid PID");
    }
	 sp_strcpy(pcb[run_pid].trapframe_p->ebx,pcb[run_pid].name); // prob wrong
}

/**
 * System call kernel handler: sleep
 * Puts the currently running process to sleep
 */
void ksyscall_sleep() {
	int tmp;
    // Don't do anything if the running PID is invalid
	if (run_pid < 0 || run_pid > PID_MAX) {
        panic("Invalid PID");
    }
    // Calculate the wake time for the currently running process
    // Store this time in the pcb's wake_time member //?????????
		// cal based on cur systime tic 100/sec
		//pcb[run_pid].trapframe_p->eax // sleep time in seconds , * 100 --> how many ticks it should be sleeping for + cur_system_time ==> wake time 
	tmp = pcb[run_pid].trapframe_p->ebx;
	pcb[run_pid].wake_time = (tmp * 100) + system_time - PROC_TICKS_MAX;
	
    // Move the currently running process to the sleep queue
	enqueue(&sleep_q,run_pid);
    // Change the running process state to SLEEP
	pcb[run_pid].state = SLEEPING;
    // Clear the running PID so the process scheduler will run
	run_pid = -1;
}

void ksyscall_exit() {
	
		if (run_pid < 0 || run_pid > PID_MAX) {
			panic("Invalid PID! \n");
	    }		
	    // Change the state of the running process to AVAILABLE
	    // Queue it back to the available queue
	    // clear the running pid
		pcb[run_pid].state = AVAILABLE;
		enqueue(&available_q,run_pid); // still prob wrong
		run_pid = -1;
		
}

void ksyscall_sem_init() {
	// errror check is SEMPHAPHORE_UNINTALIZED = -1 
	if(semaphores[run_pid].init != SEMAPHORE_UNINITIALIZED && pcb[run_pid].trapframe_p->ebx == SEMAPHORE_INITIALIZED) { 
		// get id from pointer passed in
		semaphores[run_pid].init = pcb[run_pid].trapframe_p->ebx;
		// check sem count = 0
		if(	semaphores[run_pid].count != 0) 
			semaphores[run_pid].count = 0;
	} else { 
		// dequeue sem from sem_queue 		//set id = item dequeued
		dequeue(&semaphore_q,&semaphores[run_pid]);
		//set count = 0
		semaphores[run_pid].count = 0;
		semaphores[run_pid].init = SEMAPHORE_INITIALIZED;
	} 
	
}
void ksyscall_sem_wait() { 

	if(semaphores[run_pid].init == SEMAPHORE_UNINITIALIZED) { 
		panic(" Semaphore is uninitialized");
	}
	if(semaphores[run_pid].count > 0) {
		printf("we waiting");
		breakpoint();
		//unschedule proc --> wait queue for given sema
		dequeue(&semaphore_q,&semaphores[run_pid].wait_q);
		//state == WAITING
		pcb[run_pid].state = WAITING;
	}

	semaphores[run_pid].count++;
}

void ksyscall_sem_post() { 
		if(semaphores[run_pid].init == SEMAPHORE_UNINITIALIZED) { 
			panic(" Semaphore is uninitialized");
	} else { 
		if(semaphores[run_pid].count > 0) {
			//sem wait --> kernel run
			dequeue(&semaphores[run_pid].wait_q,&run_pid);
			//enqueue(&run_q,run_pid);
			pcb[run_pid].state = READY;
			semaphores[run_pid].count--;
		}
	} 
}

void ksyscall_msg_send() { 

	if(mbox_enqueue(pcb[run_pid].trapframe_p->ebx,pcb[run_pid].trapframe_p->ecx) == -1 ) 
		panic("Mailbox full");

	if( mailboxes[run_pid].wait_q.size > 0 ) {
		// dequeue from wait --> run queue 
		dequeue(&mailboxes[run_pid].wait_q,&run_pid);
		//enqueue(&run_q,run_pid);
		//state = READY
		pcb[run_pid].state = READY;
		//get msg pointer from recv process trapframe
		mbox_dequeue(&pcb[run_pid].trapframe_p->ebx,pcb[run_pid].trapframe_p->ecx);
		//dequeue msg from mailbox --> receiving proc 
	}
}

void ksyscall_msg_recv() {
	if ( mailboxes[run_pid].size == 0 ) {
		// proc --> mailbox wait queue
		enqueue(&mailboxes[run_pid].wait_q,run_pid);
		//mailboxes[run_pid].wait_q[run_pid].state = WAITING;
		pcb[run_pid].state = WAITING;
		run_pid = -1;
	}else {
		// dequeue msg pointer from run_pid.trapframe
		if(mbox_dequeue(mailboxes[run_pid].messages[run_pid],pcb[run_pid].trapframe_p->ecx) != 0) 
			panic("Cannot dequeue msg");
		// panic if cannot deq
	}
	
}
 // mbox heleprs
int mbox_enqueue(msg_t *msg, int mbox_num) {
		mailbox_t *mbox;
		//msg_t message = *msg;
	
	if(mbox_num < 0 || mbox_num > MBOX_MAX) {
		panic("Invalid mailbox ID ");
	} // check if mailbox num is valid
	
	if(&msg == NULL) {
		panic("Invalid Message");
	}
	
	mbox = &mailboxes[mbox_num]; // set mailbox = specific mailbox in the mailbox struc 

		if( mbox->size == MBOX_MAX ) {
			return -1;
		} // box full
		
	sp_memcpy(&mbox->messages[mbox->head],msg,sizeof(*msg)); // copies msg over to mb 
	//sp_strcpy(&mbox->messages[mbox->head],&msg);
	mbox->tail++;
	
	if(mbox->tail == MBOX_SIZE) {
		mbox->tail = 0;
	} 
	
	mbox->size++;
	
	msg->time_sent = system_time / PROC_TICKS_MAX; // set time msg was sented // check PROC_TICKS_MAX part

	return 0;
}

int mbox_dequeue(msg_t *msg, int mbox_num) {

	mailbox_t *mbox;
	
	if(mbox_num < 0 || mbox_num > MBOX_MAX) {
		panic("Invalid mailbox ID ");
	} // check if mailbox num is validp
	
	if(msg == NULL) {
		panic("Invalid Message");
	}
	
	mbox = &mailboxes[mbox_num]; // set mailbox = specific mailbox in the mailbox struc 
	
	if( mbox->size == 0 ) {
		return -1;
	}
	sp_memcpy(&msg,&mbox->messages[mbox->head],sizeof(&msg)); // copies msg over from mb
	//sp_strcpy(&msg,&mbox->messages[mbox->head]);
	mbox->head++;
	
	if(mbox->head == MBOX_SIZE) {
		mbox->head = 0;
	}
	
	mbox->size--;
	
	msg->time_received = system_time / PROC_TICKS_MAX; // set time msg was sented // check PROC_TICKS_MAX part
	
	return 0;
}
